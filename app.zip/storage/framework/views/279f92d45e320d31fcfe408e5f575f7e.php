<?php
    $isDarkTheme = request()->routeIs('student.dashboard', 'teacher.dashboard', 'admin.dashboard') || (auth()->check() && (auth()->user()->isStudent() || auth()->user()->isTeacher() || auth()->user()->isAdmin()) && request()->routeIs('dashboard', 'admin.dashboard'));
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen <?php echo e($isDarkTheme ? 'bg-[#071330]' : 'bg-gray-100'); ?>">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="<?php echo e($isDarkTheme ? 'bg-[#081538] border-b-2 border-orange-500/40 shadow-xl' : 'bg-white shadow'); ?>">
                    <div class="max-w-7xl mx-auto <?php echo e($isDarkTheme ? 'p-0' : 'py-6 px-4 sm:px-6 lg:px-8'); ?>">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\jnksms\resources\views/layouts/app.blade.php ENDPATH**/ ?>